:- encoding(utf8).
% 1. PACIENTES
% paciente(Nombre, Genero, Edad, Motivo, Gravedad, Servicio, Medicos)
%
%   Genero   : femenino | masculino
%   Gravedad : leve | moderada | grave | critica
%   Servicio : pediatria | maternidad | cirugia | traumatologia |
%              medicina_interna | uci
%   Medicos  : lista de los médicos que lo atienden
%
%        Nombre     Género     Edad Motivo                     Gravedad  Servicio          Médicos
paciente(martina,   femenino,   4,  bronquiolitis,             moderada, pediatria,        [dra_soto]).
paciente(tomas,     masculino,  9,  apendicitis,               moderada, pediatria,        [dra_soto, dr_munoz]).
paciente(isidora,   femenino,  15,  crisis_asmatica,           leve,     pediatria,        [dra_soto]).
paciente(benjamin,  masculino, 17,  fractura_de_brazo,         leve,     traumatologia,    [dra_rojas]).
paciente(catalina,  femenino,  23,  parto,                     leve,     maternidad,       [dra_fuentes]).
paciente(matias,    masculino, 28,  politraumatismo,           critica,  uci,              [dr_contreras, dra_rojas]).
paciente(fernanda,  femenino,  31,  preeclampsia,              grave,    maternidad,       [dra_fuentes]).
paciente(joaquin,   masculino, 36,  apendicitis,               leve,     cirugia,          [dr_munoz]).
paciente(daniela,   femenino,  42,  colecistitis,              moderada, cirugia,          [dr_munoz]).
paciente(cristobal, masculino, 47,  pancreatitis,              grave,    medicina_interna, [dra_gonzalez]).
paciente(paula,     femenino,  53,  pielonefritis,             moderada, medicina_interna, [dra_gonzalez]).
paciente(rodrigo,   masculino, 58,  infarto_agudo,             critica,  uci,              [dr_contreras, dr_perez]).
paciente(carmen,    femenino,  64,  diabetes_descompensada,    moderada, medicina_interna, [dra_gonzalez]).
paciente(sergio,    masculino, 66,  arritmia,                  moderada, medicina_interna, [dr_perez]).
paciente(rosa,      femenino,  71,  neumonia,                  grave,    medicina_interna, [dra_gonzalez]).
paciente(hector,    masculino, 75,  accidente_cerebrovascular, critica,  uci,              [dr_contreras, dr_vargas]).
paciente(gloria,    femenino,  82,  fractura_de_cadera,        grave,    traumatologia,    [dra_rojas]).
paciente(raul,      masculino, 88,  insuficiencia_cardiaca,    grave,    medicina_interna, [dra_gonzalez, dr_perez]).

% 2. MOTIVOS DE INTERNACIÓN

% motivo(Motivo, Categoria)
motivo(neumonia,                  respiratoria).
motivo(crisis_asmatica,           respiratoria).
motivo(epoc_descompensado,        respiratoria).
motivo(bronquiolitis,             respiratoria).
motivo(infarto_agudo,             cardiovascular).
motivo(insuficiencia_cardiaca,    cardiovascular).
motivo(arritmia,                  cardiovascular).
motivo(accidente_cerebrovascular, neurologica).
motivo(convulsiones,              neurologica).
motivo(fractura_de_cadera,        traumatologica).
motivo(fractura_de_brazo,         traumatologica).
motivo(politraumatismo,           traumatologica).
motivo(apendicitis,               quirurgica).
motivo(colecistitis,              quirurgica).
motivo(gastroenteritis,           digestiva).
motivo(pancreatitis,              digestiva).
motivo(pielonefritis,             infecciosa).
motivo(celulitis,                 infecciosa).
motivo(diabetes_descompensada,    metabolica).
motivo(parto,                     obstetrica).
motivo(preeclampsia,              obstetrica).

% descripcion_motivo(Motivo, Texto)
descripcion_motivo(neumonia, 'Infección que inflama los alvéolos de uno o ambos pulmones.').
descripcion_motivo(crisis_asmatica, 'Empeoramiento agudo del asma: las vías respiratorias se estrechan y cuesta respirar.').
descripcion_motivo(epoc_descompensado, 'Empeoramiento agudo de la enfermedad pulmonar obstructiva crónica, con más falta de aire y tos.').
descripcion_motivo(bronquiolitis, 'Infección viral de los bronquiolos, frecuente en lactantes y niños pequeños.').
descripcion_motivo(infarto_agudo, 'Daño de una parte del músculo cardíaco por la obstrucción de una arteria coronaria.').
descripcion_motivo(insuficiencia_cardiaca, 'El corazón no logra bombear la sangre que el cuerpo necesita; suele causar falta de aire e hinchazón.').
descripcion_motivo(arritmia, 'Alteración del ritmo o de la frecuencia de los latidos del corazón.').
descripcion_motivo(accidente_cerebrovascular, 'Interrupción del flujo de sangre a una zona del cerebro, por obstrucción o rotura de un vaso.').
descripcion_motivo(convulsiones, 'Descargas eléctricas anormales del cerebro que provocan movimientos involuntarios o pérdida de conciencia.').
descripcion_motivo(fractura_de_cadera, 'Quiebre del extremo superior del fémur, frecuente en adultos mayores tras una caída.').
descripcion_motivo(fractura_de_brazo, 'Quiebre de alguno de los huesos del brazo.').
descripcion_motivo(politraumatismo, 'Varias lesiones simultáneas, al menos una de ellas con riesgo vital.').
descripcion_motivo(apendicitis, 'Inflamación del apéndice que habitualmente requiere cirugía.').
descripcion_motivo(colecistitis, 'Inflamación de la vesícula biliar, casi siempre causada por cálculos.').
descripcion_motivo(gastroenteritis, 'Inflamación del estómago y los intestinos que causa diarrea y vómitos.').
descripcion_motivo(pancreatitis, 'Inflamación del páncreas que provoca un dolor abdominal intenso.').
descripcion_motivo(pielonefritis, 'Infección urinaria que alcanza el riñón.').
descripcion_motivo(celulitis, 'Infección bacteriana de la piel y del tejido que está bajo ella.').
descripcion_motivo(diabetes_descompensada, 'Niveles de glucosa en la sangre fuera de control en una persona con diabetes.').
descripcion_motivo(parto, 'Internación para el nacimiento de un bebé.').
descripcion_motivo(preeclampsia, 'Presión arterial alta durante el embarazo, con riesgo para la madre y el bebé.').


% 3. MÉDICOS

% medico(Nombre, Especialidad)
medico(dra_soto,     pediatria).
medico(dr_munoz,     cirugia).
medico(dra_rojas,    traumatologia).
medico(dr_perez,     cardiologia).
medico(dra_gonzalez, medicina_interna).
medico(dr_vargas,    neurologia).
medico(dra_fuentes,  obstetricia).
medico(dr_contreras, medicina_intensiva).

% especialidad_de(Categoria, Especialidad): quién trata cada categoría de motivo.
especialidad_de(respiratoria,   medicina_interna).
especialidad_de(cardiovascular, cardiologia).
especialidad_de(neurologica,    neurologia).
especialidad_de(traumatologica, traumatologia).
especialidad_de(quirurgica,     cirugia).
especialidad_de(digestiva,      medicina_interna).
especialidad_de(infecciosa,     medicina_interna).
especialidad_de(metabolica,     medicina_interna).
especialidad_de(obstetrica,     obstetricia).

% nivel_gravedad(Gravedad, Valor): permite comparar gravedades.
nivel_gravedad(leve,     1).
nivel_gravedad(moderada, 2).
nivel_gravedad(grave,    3).
nivel_gravedad(critica,  4).

% 4. DATOS DERIVADOS: cada campo del paciente como predicado propio

% Permiten preguntar por un solo dato sin escribir los 7 campos.
genero(P, G)        :- paciente(P, G, _, _, _, _, _).
edad(P, E)          :- paciente(P, _, E, _, _, _, _).
internado_por(P, M) :- paciente(P, _, _, M, _, _, _).
gravedad(P, G)      :- paciente(P, _, _, _, G, _, _).
servicio(P, S)      :- paciente(P, _, _, _, _, S, _).
atendido_por(P, M)  :- paciente(P, _, _, _, _, _, Medicos), member(M, Medicos).

% 5. REGLAS

% R1. Rango de edad
% nino: 0-11 | adolescente: 12-17 | adulto_joven: 18-29 |
% adulto: 30-59 | adulto_mayor: 60 o más
rango_edad(P, nino)         :- edad(P, E), E < 12.
rango_edad(P, adolescente)  :- edad(P, E), E >= 12, E < 18.
rango_edad(P, adulto_joven) :- edad(P, E), E >= 18, E < 30.
rango_edad(P, adulto)       :- edad(P, E), E >= 30, E < 60.
rango_edad(P, adulto_mayor) :- edad(P, E), E >= 60.

% R2. Menor de edad
menor_de_edad(P) :- edad(P, E), E < 18.

% R3. Categoría del paciente: la categoría de su motivo.
categoria_paciente(P, Categoria) :-
    internado_por(P, Motivo),
    motivo(Motivo, Categoria).

% R4. Dos pacientes distintos con motivo de la misma categoría.
misma_categoria(P1, P2, Categoria) :-
    categoria_paciente(P1, Categoria),
    categoria_paciente(P2, Categoria),
    P1 \= P2.

% R5. Dos pacientes distintos en el mismo servicio.
mismo_servicio(P1, P2, Servicio) :-
    servicio(P1, Servicio),
    servicio(P2, Servicio),
    P1 \= P2.

% R6. Dos pacientes distintos atendidos por el mismo médico.
comparten_medico(P1, P2, Medico) :-
    atendido_por(P1, Medico),
    atendido_por(P2, Medico),
    P1 \= P2.

% R7. Un paciente está más grave que otro.
mas_grave_que(P1, P2) :-
    gravedad(P1, G1), nivel_gravedad(G1, V1),
    gravedad(P2, G2), nivel_gravedad(G2, V2),
    V1 > V2.

% R8. Requiere UCI si su estado es crítico.
requiere_uci(P) :- gravedad(P, critica).

% R9. Alto riesgo: estado crítico, o grave y adulto mayor.
alto_riesgo(P) :- gravedad(P, critica).
alto_riesgo(P) :- gravedad(P, grave), rango_edad(P, adulto_mayor).

% R10. Prioridad de atención (1 = máxima).
prioridad(P, 1) :- requiere_uci(P).
prioridad(P, 2) :- alto_riesgo(P), \+ requiere_uci(P).
prioridad(P, 3) :- gravedad(P, G), member(G, [grave, moderada]), \+ alto_riesgo(P).
prioridad(P, 4) :- gravedad(P, leve).

% R11. Error de ubicación: paciente crítico que no está en la UCI.
critico_fuera_de_uci(P) :- requiere_uci(P), \+ servicio(P, uci).

% R12. Candidato a alta: paciente en estado leve.
candidato_alta(P) :- gravedad(P, leve).

% R13. Especialidad adecuada para un paciente:
%      pediatría si es menor, medicina intensiva si es crítico y,
%      siempre, la que trata la categoría de su motivo.
especialidad_adecuada(P, pediatria)          :- menor_de_edad(P).
especialidad_adecuada(P, medicina_intensiva) :- requiere_uci(P).
especialidad_adecuada(P, Esp) :-
    categoria_paciente(P, Cat),
    especialidad_de(Cat, Esp).

% R14. Un médico puede atender a un paciente si tiene una especialidad adecuada.
puede_atender(Medico, P) :-
    medico(Medico, Esp),
    especialidad_adecuada(P, Esp).

% R15. Carga de trabajo: cantidad de pacientes de un médico.
carga_medico(Medico, N) :-
    medico(Medico, _),
    findall(P, atendido_por(P, Medico), Lista),
    length(Lista, N).

% 6. VOCABULARIO PARA EL CHATBOT

% sinonimo(Texto, Atomo): otras formas de nombrar un valor de la base.
% (El chatbot reconoce además el plural de cada texto: mujer -> mujeres).
sinonimo('mujer',               femenino).
sinonimo('femenina',            femenino).
sinonimo('hombre',              masculino).
sinonimo('varon',               masculino).
sinonimo('nina',                nino).
sinonimo('adultos jovenes',     adulto_joven).
sinonimo('adultos mayores',     adulto_mayor).
sinonimo('anciano',             adulto_mayor).
sinonimo('anciana',             adulto_mayor).
sinonimo('tercera edad',        adulto_mayor).
sinonimo('critico',             critica).
sinonimo('estado critico',      critica).
sinonimo('moderado',            moderada).
sinonimo('cuidados intensivos', uci).
sinonimo('terapia intensiva',   uci).
sinonimo('intensivo',           uci).
sinonimo('infarto',             infarto_agudo).
sinonimo('acv',                 accidente_cerebrovascular).
sinonimo('ataque cerebral',     accidente_cerebrovascular).
sinonimo('derrame cerebral',    accidente_cerebrovascular).
sinonimo('pulmonia',            neumonia).
sinonimo('asma',                crisis_asmatica).
sinonimo('diabetes',            diabetes_descompensada).
sinonimo('cardiaco',            cardiovascular).
sinonimo('cardiaca',            cardiovascular).
sinonimo('corazon',             cardiovascular).
sinonimo('respiratorio',        respiratoria).
sinonimo('pulmonar',            respiratoria).
sinonimo('neurologico',         neurologica).
sinonimo('traumatologico',      traumatologica).
sinonimo('trauma',              traumatologica).
sinonimo('quirurgico',          quirurgica).
sinonimo('digestivo',           digestiva).
sinonimo('gastrico',            digestiva).
sinonimo('infeccion',           infecciosa).
sinonimo('infeccioso',          infecciosa).
sinonimo('metabolico',          metabolica).
sinonimo('obstetrico',          obstetrica).
sinonimo('embarazada',          obstetrica).
sinonimo('embarazo',            obstetrica).

% nombre_especialista(Texto, Especialidad): cómo se llama a quien la ejerce.
nombre_especialista('cardiologo',   cardiologia).
nombre_especialista('cardiologa',   cardiologia).
nombre_especialista('neurologo',    neurologia).
nombre_especialista('neurologa',    neurologia).
nombre_especialista('pediatra',     pediatria).
nombre_especialista('cirujano',     cirugia).
nombre_especialista('cirujana',     cirugia).
nombre_especialista('traumatologo', traumatologia).
nombre_especialista('traumatologa', traumatologia).
nombre_especialista('obstetra',     obstetricia).
nombre_especialista('intensivista', medicina_intensiva).
nombre_especialista('internista',   medicina_interna).


