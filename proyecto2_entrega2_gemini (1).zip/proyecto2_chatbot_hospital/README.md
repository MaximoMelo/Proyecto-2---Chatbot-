# Chatbot de pacientes hospitalizados

Proyecto N°2 de Fundamentos de Inteligencia Artificial. Un chatbot que responde preguntas sobre los
pacientes de un hospital ficticio, implementado de dos formas sobre el mismo conocimiento:

| Archivo | Qué es | Punto del enunciado |
| --- | --- | --- |
| `hospital.pl` | Base de conocimiento en lógica de primer orden (hechos y 15 reglas) | 2 |
| `chatbot.py` | Chatbot que razona con Prolog (vía `pyswip`) | 3 |
| `chatbot_llm.py` | Chatbot que usa Gemini con `hospital.pl` como contexto | 4 |
| `app.py` + `templates/index.html` | Interfaz web para ambos chatbots (Flask) | 5 |
| `evaluar.py` | Corre las 20 preguntas del informe en ambas versiones | 6 |

Todos los datos son ficticios.

## Instalación (una sola vez)

1. **SWI-Prolog 9**: <https://www.swi-prolog.org/download/stable>. En Windows, marcar "Add swipl to the system PATH".
2. **Python 3.10 o superior**, marcando "Add Python to PATH".
3. Abrir PowerShell en esta carpeta e instalar las librerías:

   ```powershell
   pip install -r requirements.txt
   ```

4. **API key de Gemini** (gratis): entrar a <https://aistudio.google.com>, ir a "Get API key" y crear una.
   La clave **no se escribe en el código**. Hay dos formas de entregarla:

   - **Archivo `.env`** (recomendado): copiar `.env.ejemplo`, renombrar la copia a `.env` y reemplazar el texto por la clave. Debe quedar una sola línea:

     ```
     GEMINI_API_KEY=pega-aqui-la-clave
     ```

     El archivo `.gitignore` ya excluye `.env`, así que la clave no se sube al repositorio.

   - **Variable de entorno**, en PowerShell (dura mientras la ventana esté abierta):

     ```powershell
     $env:GEMINI_API_KEY = "pega-aqui-la-clave"
     ```

## Uso

```powershell
python app.py              # interfaz web: abrir http://127.0.0.1:5000
python chatbot.py          # chatbot Prolog en consola
python chatbot_llm.py      # chatbot Gemini en consola
python evaluar.py          # corre las 20 preguntas y genera resultados_evaluacion.md / .csv
```

Los chatbots de consola aceptan `ayuda`, `recargar` (vuelve a leer `hospital.pl` sin reiniciar) y `salir`.
En la web, el selector de arriba elige la versión: Prolog, Gemini o "Comparar" (ambas lado a lado).
Para detener la web: `Ctrl + C`.

Si falta la API key, la web y `evaluar.py` siguen funcionando con la versión Prolog y explican qué falta.

## Modelo de Gemini

El programa prueba estos modelos en orden y usa el primero disponible:
`gemini-3.5-flash`, `gemini-flash-latest`, `gemini-3.1-flash-lite`, `gemini-2.5-flash`.
Si Google retira uno, pasa solo al siguiente. Para forzar otro modelo:

```powershell
$env:GEMINI_MODEL = "nombre-del-modelo"
```

| Mensaje | Qué hacer |
| --- | --- |
| "Falta la API key de Gemini" | Crear el archivo `.env` o definir la variable |
| "Gemini rechazó la API key" | Revisar que la clave esté bien copiada, sin espacios |
| "Se alcanzó el límite de uso gratuito" | Esperar un minuto y repetir |
| "Ninguno de estos modelos está disponible" | Definir `GEMINI_MODEL` con un modelo que aparezca en AI Studio |

## Modificar el conocimiento

Todo cambio se hace en `hospital.pl` y se aplica con `recargar` (consola) o el botón "Recargar base" (web).
Ambas versiones leen el mismo archivo, así que el cambio llega a las dos.

```prolog
% Agregar una paciente: una sola línea
paciente(andrea, femenino, 67, neumonia, grave, medicina_interna, [dra_gonzalez]).
```

| Cambio | Qué editar |
| --- | --- |
| Gravedad o servicio de un paciente | El campo en su línea `paciente(...)` |
| Médicos de un paciente | La lista al final de su línea |
| Nuevo médico | `medico(nombre, especialidad).` |
| Nuevo motivo | `motivo(nombre, categoria).` |
| Otra forma de nombrar algo | `sinonimo('texto', atomo).` |
| Un criterio (por ejemplo, desde qué edad se es adulto mayor) | La regla correspondiente, como `rango_edad/2` |
