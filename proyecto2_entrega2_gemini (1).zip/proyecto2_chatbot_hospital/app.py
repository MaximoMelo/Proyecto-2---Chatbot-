"""Interfaz web del chatbot de pacientes hospitalizados (punto 5 del proyecto).

Sirve una página con un chat que permite preguntar a la versión Prolog, a la
versión LLM o a ambas a la vez para comparar sus respuestas.

Uso:
    python app.py        # luego abrir http://127.0.0.1:5000 en el navegador
"""

from __future__ import annotations

import threading

from flask import Flask, jsonify, render_template, request

from chatbot import Chatbot
from chatbot_llm import ChatbotLLM, ErrorLLM

app = Flask(__name__)

# SWI-Prolog no admite consultas simultáneas desde varios hilos: un candado
# asegura que se atienda una consulta a la vez.
_candado_prolog = threading.Lock()
bot_prolog = Chatbot()

# Gemini es opcional: si falta la API key, la web funciona igual con Prolog.
try:
    bot_llm: ChatbotLLM | None = ChatbotLLM()
    error_llm = None
except (ErrorLLM, FileNotFoundError) as error:
    bot_llm = None
    error_llm = str(error)


def preguntar_prolog(pregunta: str) -> str:
    with _candado_prolog:
        try:
            return bot_prolog.responder(pregunta)
        except Exception as error:  # una pregunta rara no debe botar el servidor
            return f"Ocurrió un error al consultar Prolog: {error}"


def preguntar_llm(pregunta: str) -> str:
    if bot_llm is None:
        return f"La versión con Gemini no está disponible. {error_llm}"
    return bot_llm.responder(pregunta)


@app.get("/")
def inicio():
    descripcion_llm = "Gemini" if bot_llm else "Gemini no configurado"
    return render_template("index.html", descripcion_llm=descripcion_llm)


@app.post("/api/preguntar")
def api_preguntar():
    datos = request.get_json(silent=True) or {}
    pregunta = str(datos.get("pregunta", "")).strip()[:500]
    motor = datos.get("motor", "prolog")
    if not pregunta:
        return jsonify(error="La pregunta está vacía."), 400
    if motor not in {"prolog", "llm", "ambos"}:
        return jsonify(error="Motor desconocido."), 400

    respuesta = {}
    if motor in {"prolog", "ambos"}:
        respuesta["prolog"] = preguntar_prolog(pregunta)
    if motor in {"llm", "ambos"}:
        respuesta["llm"] = preguntar_llm(pregunta)
    return jsonify(respuesta)


@app.post("/api/recargar")
def api_recargar():
    """Vuelve a leer hospital.pl en ambos chatbots, sin reiniciar el servidor."""
    with _candado_prolog:
        bot_prolog.recargar()
    if bot_llm is not None:
        bot_llm.recargar()
    return jsonify(ok=True)


if __name__ == "__main__":
    # threaded=False: Prolog debe ejecutarse siempre en el mismo hilo.
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=False)
