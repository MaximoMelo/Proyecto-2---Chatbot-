"""Chatbot de pacientes hospitalizados usando Gemini (punto 4 del proyecto).

Usa el MISMO conocimiento que la versión en Prolog: el archivo hospital.pl se
entrega completo a Gemini como contexto, junto con instrucciones para que
responda solo a partir de esa base.

La API key se obtiene gratis en https://aistudio.google.com ("Get API key") y
se entrega al programa de una de estas dos formas (nunca dentro del código):

    1. Variable de entorno, en PowerShell:
           $env:GEMINI_API_KEY = "tu-clave"
    2. Archivo .env en esta misma carpeta, con la línea:
           GEMINI_API_KEY=tu-clave

Opcional: GEMINI_MODEL elige otro modelo (por defecto se prueban los de MODELOS).

Uso:
    python chatbot_llm.py                 # modo conversación
    python chatbot_llm.py "pregunta"      # responde una sola pregunta
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import requests

CARPETA = Path(__file__).resolve().parent
RUTA_POR_DEFECTO = CARPETA / "hospital.pl"

# Modelos que se prueban en orden. Si Google retira uno, se usa el siguiente.
MODELOS = ["gemini-3.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite", "gemini-2.5-flash"]

URL_API = "https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
TIEMPO_MAXIMO = 60  # segundos de espera por respuesta

INSTRUCCIONES = """Eres el asistente de un hospital ficticio. Respondes preguntas en español sobre
los pacientes internados usando EXCLUSIVAMENTE la base de conocimiento en Prolog que aparece abajo.

Cómo leer la base:
- Cada hecho paciente(Nombre, Genero, Edad, Motivo, Gravedad, Servicio, Medicos) describe un paciente.
- Las reglas (líneas con ":-") definen conocimiento que se deduce: rango de edad, alto riesgo,
  prioridad, candidato a alta, qué médico puede atender a un paciente, etc. Aplícalas tal como están
  escritas para responder.
- Las secciones de sinónimos solo indican otras formas de nombrar los mismos valores.

Reglas para responder:
1. Usa solo la información de la base. No inventes pacientes, datos ni criterios médicos.
2. Si la pregunta pide un dato que la base no tiene (por ejemplo alergias o días de internación),
   di claramente que ese dato no está registrado.
3. Si la pregunta no trata sobre el hospital o sus pacientes, responde que solo puedes contestar
   preguntas sobre los pacientes del hospital.
4. Responde de forma breve y directa, en uno a tres párrafos cortos o una lista corta.
5. Escribe los nombres de forma legible: "Raúl" en vez de raul, "Dr. Pérez" en vez de dr_perez,
   "medicina interna" en vez de medicina_interna.

BASE DE CONOCIMIENTO (hospital.pl):
"""


class ErrorLLM(Exception):
    """Error de configuración o de comunicación con Gemini."""


def leer_clave() -> str:
    """Busca la API key en la variable de entorno o en el archivo .env de la carpeta."""
    clave = os.getenv("GEMINI_API_KEY", "").strip()
    archivo_env = CARPETA / ".env"
    if not clave and archivo_env.exists():
        for linea in archivo_env.read_text(encoding="utf-8").splitlines():
            nombre, _, valor = linea.partition("=")
            if nombre.strip() == "GEMINI_API_KEY":
                clave = valor.strip().strip('"').strip("'")
    if not clave:
        raise ErrorLLM("Falta la API key de Gemini: define GEMINI_API_KEY "
                       "o créala en un archivo .env (ver README).")
    return clave


class ChatbotLLM:
    """Chatbot que responde con Gemini usando hospital.pl como contexto."""

    def __init__(self, ruta: str | Path = RUTA_POR_DEFECTO, modelo: str | None = None):
        self.ruta = Path(ruta)
        self.clave = leer_clave()
        elegido = modelo or os.getenv("GEMINI_MODEL")
        self.modelos = [elegido] if elegido else list(MODELOS)
        self.modelo = self.modelos[0]
        self.recargar()

    def recargar(self) -> None:
        """Vuelve a leer hospital.pl (para usar los cambios sin reiniciar)."""
        if not self.ruta.exists():
            raise FileNotFoundError(f"No se encontró la base de conocimiento: {self.ruta}")
        self.instrucciones = INSTRUCCIONES + self.ruta.read_text(encoding="utf-8")

    def responder(self, pregunta: str) -> str:
        pregunta = pregunta.strip()
        if not pregunta:
            return "Escribe una pregunta sobre los pacientes del hospital."
        try:
            return self._preguntar(pregunta).strip()
        except requests.Timeout:
            return "Gemini tardó demasiado en responder. Intenta de nuevo."
        except requests.RequestException as error:
            return f"No pude comunicarme con Gemini: {error}"
        except ErrorLLM as error:
            return str(error)

    def _preguntar(self, pregunta: str) -> str:
        cuerpo = {
            "system_instruction": {"parts": [{"text": self.instrucciones}]},
            "contents": [{"role": "user", "parts": [{"text": pregunta}]}],
            "generationConfig": {"temperature": 0},
        }
        # Se prueba primero el último modelo que funcionó y luego los demás.
        pendientes = [self.modelo] + [m for m in self.modelos if m != self.modelo]
        for modelo in pendientes:
            respuesta = requests.post(URL_API.format(modelo=modelo), json=cuerpo,
                                      headers={"x-goog-api-key": self.clave}, timeout=TIEMPO_MAXIMO)
            if respuesta.status_code == 404:  # modelo retirado o inexistente: probar el siguiente
                continue
            if respuesta.status_code == 429:
                raise ErrorLLM("Se alcanzó el límite de uso gratuito de Gemini. Espera un minuto y vuelve a intentar.")
            if respuesta.status_code in (400, 401, 403) and "API key" in respuesta.text:
                raise ErrorLLM("Gemini rechazó la API key. Revisa que esté bien copiada.")
            if respuesta.status_code != 200:
                raise ErrorLLM(f"Gemini respondió con error {respuesta.status_code}: {respuesta.text[:300]}")
            self.modelo = modelo
            return self._extraer_texto(respuesta.json())
        raise ErrorLLM(f"Ninguno de estos modelos está disponible: {', '.join(pendientes)}. "
                       "Define GEMINI_MODEL con un modelo que aparezca en AI Studio.")

    @staticmethod
    def _extraer_texto(datos: dict) -> str:
        try:
            partes = datos["candidates"][0]["content"]["parts"]
        except (KeyError, IndexError):
            raise ErrorLLM(f"Respuesta inesperada de Gemini: {str(datos)[:300]}")
        return "".join(p.get("text", "") for p in partes)


# ======================================================================
# Interfaz de consola (igual que la versión Prolog)
# ======================================================================
COMANDOS_SALIDA = {"salir", "exit", "quit", "chao", "adios", "adiós"}


def main() -> None:
    try:
        bot = ChatbotLLM()
    except (ErrorLLM, FileNotFoundError) as error:
        print(error)
        sys.exit(1)

    if len(sys.argv) > 1:
        print(bot.responder(" ".join(sys.argv[1:])))
        return

    print("Chatbot de pacientes con Gemini  (escribe 'recargar' tras editar el .pl, 'salir' para terminar)\n")
    while True:
        try:
            pregunta = input("Tú: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n¡Hasta luego!")
            break
        if pregunta.lower() in COMANDOS_SALIDA:
            print("Bot: ¡Hasta luego!")
            break
        if pregunta.lower() == "recargar":
            bot.recargar()
            print("Bot: Base de conocimiento recargada.\n")
            continue
        print(f"Bot: {bot.responder(pregunta)}\n")


if __name__ == "__main__":
    main()
