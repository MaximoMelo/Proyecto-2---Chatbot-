"""Evaluación de desempeño: corre las 20 preguntas del informe en ambas versiones.

Uso (con la API key de Gemini configurada, ver README):
    python evaluar.py

Genera:
    resultados_evaluacion.md    tabla lista para revisar o pegar en el informe
    resultados_evaluacion.csv   los mismos datos para Excel o Google Sheets

Si Gemini no está configurado, igual corre la versión Prolog y deja la columna
de Gemini con el motivo.
"""

from __future__ import annotations

import csv
import time
from pathlib import Path

from chatbot import Chatbot
from chatbot_llm import ChatbotLLM, ErrorLLM

CARPETA = Path(__file__).resolve().parent

# (pregunta, respuesta esperada según hospital.pl)
PREGUNTAS = [
    ("Háblame de Raúl",
     "88 años, masculino, adulto mayor; insuficiencia cardíaca (cardiovascular); grave; medicina interna; "
     "Dr. Pérez y Dra. González; prioridad 2; alto riesgo."),
    ("¿Por qué está internado Héctor?", "Por accidente cerebrovascular (categoría neurológica)."),
    ("¿Está Rosa en la UCI?", "No, está en medicina interna."),
    ("¿Qué prioridad tiene Matías?", "Prioridad 1 (estado crítico, requiere UCI)."),
    ("¿Es Gloria de alto riesgo?", "Sí: está grave y es adulto mayor (82 años)."),
    ("¿Es Fernanda de alto riesgo?", "No: está grave, pero tiene 31 años (no es adulto mayor)."),
    ("¿Puede Isidora irse de alta?", "Sí: está en estado leve."),
    ("¿Quién puede atender a Sergio?", "El Dr. Pérez (cardiología)."),
    ("¿Puede el Dr. Pérez atender a Gloria?", "No: Gloria necesita traumatología (Dra. Rojas)."),
    ("¿Qué tienen en común Joaquín y Tomás?",
     "Motivo de la misma categoría (quirúrgica, apendicitis), los atiende el Dr. Muñoz y son hombres."),
    ("Mujeres en estado grave", "Fernanda, Gloria y Rosa."),
    ("Adultos mayores en medicina interna", "Carmen, Raúl, Rosa y Sergio."),
    ("Pacientes por gravedad", "Crítica 3, grave 5, moderada 6, leve 4 (18 en total)."),
    ("¿Quién es el paciente más joven?", "Martina, 4 años."),
    ("¿Qué es la pielonefritis?",
     "Infección urinaria que alcanza el riñón; categoría infecciosa; la trata medicina interna; paciente: Paula."),
    ("¿Hay algún paciente crítico que no esté en la UCI?", "No: los 3 pacientes críticos están en la UCI."),
    ("¿Qué médico trata las enfermedades del corazón?", "El Dr. Pérez (cardiología)."),
    ("¿Cuál es el motivo de internación más común?", "Apendicitis (Tomás y Joaquín)."),
    ("¿Cuántos días lleva internado Raúl?", "Ese dato no está registrado en la base."),
    ("¿Cuál es la capital de Francia?", "Fuera del dominio: debe indicar que solo responde sobre el hospital."),
]


def main() -> None:
    bot_prolog = Chatbot()
    try:
        bot_llm = ChatbotLLM()
        nombre_llm = "Gemini"
    except (ErrorLLM, FileNotFoundError) as error:
        bot_llm, nombre_llm = None, f"no configurado ({error})"

    print(f"Evaluando {len(PREGUNTAS)} preguntas · LLM: {nombre_llm}\n")
    filas = []
    for i, (pregunta, esperada) in enumerate(PREGUNTAS, start=1):
        inicio = time.perf_counter()
        r_prolog = bot_prolog.responder(pregunta)
        t_prolog = time.perf_counter() - inicio

        if bot_llm:
            inicio = time.perf_counter()
            r_llm = bot_llm.responder(pregunta)
            t_llm = time.perf_counter() - inicio
        else:
            r_llm, t_llm = "Gemini no configurado.", 0.0

        filas.append({"n": i, "pregunta": pregunta, "esperada": esperada,
                      "prolog": r_prolog, "t_prolog": round(t_prolog, 3),
                      "llm": r_llm, "t_llm": round(t_llm, 2)})
        print(f"{i:2}. {pregunta}  (Prolog {t_prolog:.3f}s · Gemini {t_llm:.2f}s)")

    with open(CARPETA / "resultados_evaluacion.csv", "w", newline="", encoding="utf-8-sig") as f:
        escritor = csv.DictWriter(f, fieldnames=list(filas[0]))
        escritor.writeheader()
        escritor.writerows(filas)

    def celda(texto: str) -> str:
        return str(texto).replace("|", "\\|").replace("\n", "<br>")

    if bot_llm:
        nombre_llm = f"Gemini ({bot_llm.modelo})"  # el modelo que realmente respondió
    lineas = [f"# Resultados de la evaluación\n\nLLM usado: {nombre_llm}\n",
              "| # | Pregunta | Respuesta esperada | Prolog | LLM |",
              "| --- | --- | --- | --- | --- |"]
    for f_ in filas:
        lineas.append(f"| {f_['n']} | {celda(f_['pregunta'])} | {celda(f_['esperada'])} | "
                      f"{celda(f_['prolog'])} | {celda(f_['llm'])} |")
    (CARPETA / "resultados_evaluacion.md").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("\nListo: resultados_evaluacion.md y resultados_evaluacion.csv")


if __name__ == "__main__":
    main()
