from __future__ import annotations

import re
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from pyswip import Prolog



# Al reemplazar "_" por espacios, quedan sin tildes o mal escritos.
NOMBRES_ESPECIALES = {
    # pacientes
    "tomas": "Tomás", "benjamin": "Benjamín", "matias": "Matías", "joaquin": "Joaquín",
    "cristobal": "Cristóbal", "hector": "Héctor", "raul": "Raúl",
    # motivos y categorías
    "neumonia": "neumonía", "crisis_asmatica": "crisis asmática",
    "epoc_descompensado": "EPOC descompensado", "insuficiencia_cardiaca": "insuficiencia cardíaca",
    "neurologica": "neurológica", "traumatologica": "traumatológica",
    "quirurgica": "quirúrgica", "metabolica": "metabólica", "obstetrica": "obstétrica",
    # gravedad, rangos y género
    "critica": "crítica", "nino": "niño", "adulto_joven": "adulto joven",
    "adulto_mayor": "adulto mayor",
    # servicios y especialidades
    "uci": "UCI", "pediatria": "pediatría", "cirugia": "cirugía",
    "traumatologia": "traumatología", "cardiologia": "cardiología", "neurologia": "neurología",
    # antecedentes
    "hipertension": "hipertensión", "epoc": "EPOC", "latex": "látex", "aines": "AINES",
}

APELLIDOS = {"munoz": "Muñoz", "perez": "Pérez", "gonzalez": "González"}

TITULOS = {"dr": "Dr.", "dra": "Dra."}


def nombre(atomo, persona: bool = False) -> str:
    """Texto legible para un átomo. A las personas se les pone mayúscula inicial."""
    atomo = str(atomo)
    prefijo, _, apellido = atomo.partition("_")
    if prefijo in TITULOS and apellido:  # médicos: dr_perez -> Dr. Pérez
        return f"{TITULOS[prefijo]} {APELLIDOS.get(apellido, apellido.capitalize())}"
    texto = NOMBRES_ESPECIALES.get(atomo, atomo.replace("_", " "))
    if persona:
        texto = texto[0].upper() + texto[1:]
    return texto


def enumerar(elementos, persona: bool = False, conjuncion: str = "y") -> str:
    """['a', 'b', 'c'] -> 'a, b y c'."""
    nombres = [nombre(e, persona) for e in elementos]
    if not nombres:
        return ""
    if len(nombres) == 1:
        return nombres[0]
    return ", ".join(nombres[:-1]) + f" {conjuncion} " + nombres[-1]


def capitalizar(texto: str) -> str:
    return texto[:1].upper() + texto[1:] if texto else texto


def pacientes_txt(n: int) -> str:
    return "1 paciente" if n == 1 else f"{n} pacientes"


def dias_txt(n: int) -> str:
    return "1 día" if n == 1 else f"{n} días"


# Gravedad dicha como estado: "estado crítico", "estado moderado".
ESTADO = {"critica": "crítico", "moderada": "moderado"}


def estado(gravedad: str) -> str:
    return ESTADO.get(gravedad, nombre(gravedad))


def con_articulo(medico: str) -> str:
    """dra_soto -> 'la Dra. Soto', dr_perez -> 'el Dr. Pérez'."""
    return ("la " if medico.startswith("dra_") else "el ") + nombre(medico)


# Al quedar un solo resultado, las descripciones pasan a singular.
SINGULARES = {"internados": "internado", "atendidos": "atendido", "alérgicos": "alérgico",
              "candidatos": "candidato", "menores": "menor", "mayores": "mayor"}


def singular(texto: str) -> str:
    return " ".join(SINGULARES.get(p, p) for p in texto.split())



# Base de conocimiento mediante comunicación con prolog

RUTA_POR_DEFECTO = Path(__file__).resolve().parent / "hospital.pl"


def _a_python(valor):
    """Convierte los valores que entrega pyswip a tipos simples de Python."""
    if isinstance(valor, (int, float)):
        return valor
    if isinstance(valor, bytes):
        return valor.decode("utf-8")
    return str(valor)


class BaseConocimiento:
    """Envoltorio sobre el motor Prolog con consultas de alto nivel."""

    def __init__(self, ruta: str | Path = RUTA_POR_DEFECTO):
        self.ruta = Path(ruta)
        if not self.ruta.exists():
            raise FileNotFoundError(f"No se encontró la base de conocimiento: {self.ruta}")
        self._prolog = Prolog()
        self.recargar()

    def recargar(self) -> None:
        """Vuelve a leer el archivo .pl (útil si se edita durante la ejecución)."""
        self._prolog.consult(self.ruta.as_posix())

    # Consultas genéricas
    def es_cierto(self, objetivo: str) -> bool:
        """¿Prolog puede demostrar el objetivo?"""
        return bool(list(self._prolog.query(objetivo, maxresult=1)))

    def lista(self, plantilla: str, objetivo: str) -> list:
        """Todas las soluciones distintas de `plantilla` que cumplen `objetivo`, ordenadas."""
        consulta = f"findall({plantilla}, ({objetivo}), Lista)"
        resultado = list(self._prolog.query(consulta, maxresult=1))
        if not resultado:
            return []
        valores = {_a_python(v) for v in resultado[0]["Lista"]}
        return sorted(valores, key=str)

    def valor(self, variable: str, objetivo: str):
        """Primera solución para `variable`, o None si no hay."""
        resultado = list(self._prolog.query(objetivo, maxresult=1))
        if not resultado:
            return None
        return _a_python(resultado[0][variable])

    def pares(self, var1: str, var2: str, objetivo: str) -> list[tuple]:
        """Pares distintos (var1, var2) que cumplen el objetivo."""
        vistos = []
        for sol in self._prolog.query(objetivo):
            par = (_a_python(sol[var1]), _a_python(sol[var2]))
            if par not in vistos:
                vistos.append(par)
        return vistos

    # Vocabulario del dominio (lo usa el procesador de lenguaje)
    def vocabulario(self) -> dict[str, list[str]]:
        """Entidades conocidas, agrupadas por clase, extraídas desde la propia base."""
        return {
            "paciente": self.lista("P", "genero(P, _)"),
            "medico": self.lista("M", "medico(M, _)"),
            "motivo": self.lista("M", "motivo(M, _)"),
            "categoria": self.lista("C", "motivo(_, C)"),
            "gravedad": self.lista("G", "nivel_gravedad(G, _)"),
            "rango": ["nino", "adolescente", "adulto_joven", "adulto", "adulto_mayor"],
            "genero": self.lista("G", "genero(_, G)"),
            "servicio": self.lista("S", "servicio(_, S)"),
            "especialidad": self.lista("E", "medico(_, E)"),
        }

    def sinonimos(self) -> list[tuple[str, str]]:
        return self.pares("T", "A", "sinonimo(T, A)")

    def nombres_especialista(self) -> list[tuple[str, str]]:
        return self.pares("T", "E", "nombre_especialista(T, E)")


# Procesamiento de lenguaje
# Si un mismo texto corresponde a varias clases, gana la que aparece primero.
PRIORIDAD = ["paciente", "medico", "motivo", "cronica", "sustancia", "categoria",
             "gravedad", "rango", "genero", "servicio", "especialidad", "especialista"]

VOCALES = "aeiou"

# Una entidad se considera negada si va justo después de "sin" ("sin alergias")
# o si hay un "no" o un "fuera" entre las 3 palabras anteriores ("no están en estado grave").


def normalizar(texto: str) -> str:
    """Minúsculas, sin tildes ni signos de puntuación y con espacios simples."""
    texto = unicodedata.normalize("NFD", texto.lower())
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    texto = re.sub(r"[^a-z0-9]+", " ", texto)
    return texto.strip()


def _plural(palabra: str) -> str:
    if palabra.endswith("s"):
        return palabra
    if palabra.endswith("z"):
        return palabra[:-1] + "ces"
    if palabra[-1] in VOCALES:
        return palabra + "s"
    return palabra + "es"


def _singular(palabra: str) -> str:
    if palabra.endswith("es") and len(palabra) > 4 and palabra[-3] not in VOCALES:
        return palabra[:-2]
    if palabra.endswith("s") and len(palabra) > 3:
        return palabra[:-1]
    return palabra


def formas(texto: str) -> set[str]:
    """Variantes con que se puede mencionar una entidad (singular y plural de la 1ª palabra)."""
    palabras = texto.split()
    resto = palabras[1:]
    return {
        texto,
        " ".join([_plural(palabras[0])] + resto),
        " ".join([_singular(palabras[0])] + resto),
    }


def formas_medico(atomo: str) -> set[str]:
    """dr_perez -> {'perez', 'dr perez', 'doctor perez', ...}."""
    prefijo, _, apellido = atomo.partition("_")
    if prefijo not in TITULOS or not apellido:
        return set()
    tratamientos = ["dr", "doctor"] if prefijo == "dr" else ["dra", "doctora"]
    return {apellido} | {f"{t} {apellido}" for t in tratamientos}


@dataclass(frozen=True)
class Entidad:
    clase: str      
    valor: str      
    inicio: int     
    negada: bool    


class Analizador:
    """Encuentra en una pregunta las entidades conocidas por la base."""
    def __init__(self, vocabulario: dict[str, list[str]], sinonimos: list[tuple[str, str]],
                 especialistas: list[tuple[str, str]]):
        self.indice: dict[str, tuple[str, str]] = {}

        # Se recorre de menor a mayor prioridad: la de mayor prioridad sobrescribe.
        for clase in reversed(PRIORIDAD):
            for valor in vocabulario.get(clase, []):
                for forma in formas(normalizar(valor.replace("_", " "))):
                    self.indice[forma] = (clase, valor)

        for texto, especialidad in especialistas:
            for forma in formas(normalizar(texto)):
                self.indice[forma] = ("especialista", especialidad)

        clase_de = {}
        for clase in reversed(PRIORIDAD):
            for valor in vocabulario.get(clase, []):
                clase_de[valor] = clase
        for texto, valor in sinonimos:
            if valor in clase_de:
                for forma in formas(normalizar(texto)):
                    self.indice[forma] = (clase_de[valor], valor)

        for medico in vocabulario.get("medico", []):
            for forma in formas_medico(medico):
                self.indice[forma] = ("medico", medico)

        # Los textos más largos se buscan primero: "insuficiencia cardiaca" antes que "cardiaca".
        self._orden = sorted(self.indice, key=len, reverse=True)

    def entidades(self, texto_normalizado: str) -> list[Entidad]:
        ocupado = [False] * len(texto_normalizado)
        encontradas = []
        for forma in self._orden:
            patron = r"(?<![a-z0-9])" + re.escape(forma) + r"(?![a-z0-9])"
            for m in re.finditer(patron, texto_normalizado):
                if any(ocupado[m.start():m.end()]):
                    continue
                for i in range(m.start(), m.end()):
                    ocupado[i] = True
                clase, valor = self.indice[forma]
                antes = texto_normalizado[:m.start()].split()
                negada = (bool(antes) and antes[-1] == "sin") or "no" in antes[-3:] or "fuera" in antes[-3:]
                encontradas.append(Entidad(clase, valor, m.start(), negada))
        encontradas.sort(key=lambda e: e.inicio)
        return encontradas


def contiene(texto: str, *claves: str) -> bool:
    """¿El texto contiene alguna palabra que comience con alguna de las claves?"""
    return any(re.search(r"(?<![a-z0-9])" + re.escape(c), texto) for c in claves)


#Consulta a prolog y redacción de respuesta

ORDEN_GRAVEDAD = ["critica", "grave", "moderada", "leve"]
ORDEN_RANGO = ["nino", "adolescente", "adulto_joven", "adulto", "adulto_mayor"]

DESCRIPCION_PRIORIDAD = {
    1: "máxima: estado crítico, requiere UCI",
    2: "alta: paciente de alto riesgo",
    3: "media: estado grave o moderado sin alto riesgo",
    4: "baja: estado leve",
}


@dataclass
class Contexto:
    """Pregunta ya procesada: texto normalizado + entidades detectadas."""

    texto: str
    entidades: list[Entidad] = field(default_factory=list)

    def todas(self, clase: str) -> list[Entidad]:
        return [e for e in self.entidades if e.clase == clase]

    def valores(self, clase: str) -> list[str]:
        vistos = []
        for e in self.todas(clase):
            if e.valor not in vistos:
                vistos.append(e.valor)
        return vistos

    def uno(self, clase: str) -> str | None:
        valores = self.valores(clase)
        return valores[0] if valores else None

    def tiene(self, *claves: str) -> bool:
        return contiene(self.texto, *claves)

    def pide_alta(self) -> bool:
        """'alta' como alta médica (no 'presión alta')."""
        return bool(re.search(r"(?<!presion )\balta\b", self.texto))


class Chatbot:
    def __init__(self, base: BaseConocimiento | None = None):
        self.kb = base or BaseConocimiento()
        self._construir_analizador()
        self._reglas = [
            self._r_saludo,
            self._r_ayuda,
            self._r_gracias,
            self._r_dos_pacientes,
            self._r_medico_paciente,
            self._r_paciente,
            self._r_medico,
            self._r_motivo,
            self._r_estadisticas,
            self._r_extremos,
            self._r_medicos,
            self._r_listado,
        ]

    def _construir_analizador(self) -> None:
        self.analizador = Analizador(
            self.kb.vocabulario(), self.kb.sinonimos(), self.kb.nombres_especialista()
        )

    def recargar(self) -> None:
        """Relee el .pl: permite modificar el conocimiento sin reiniciar el programa."""
        self.kb.recargar()
        self._construir_analizador()

    def responder(self, pregunta: str) -> str:
        texto = normalizar(pregunta)
        if not texto:
            return "Escribe una pregunta sobre los pacientes del hospital. Escribe 'ayuda' para ver ejemplos."
        ctx = Contexto(texto, self.analizador.entidades(texto))
        for regla in self._reglas:
            respuesta = regla(ctx)
            if respuesta:
                return respuesta
        return (
            "No logré entender la pregunta. Prueba con algo como "
            "'¿Por qué está internado Héctor?' o escribe 'ayuda'."
        )

    # Reglas conversacionales - Inicio de chat
    def _r_saludo(self, ctx: Contexto):
        if ctx.tiene("hola", "buenas", "buenos dias", "buen dia") and not ctx.entidades and len(ctx.texto.split()) <= 4:
            return ("¡Hola! Soy el asistente de pacientes hospitalizados. Pregúntame por pacientes, "
                    "gravedad, motivos de internación, servicios o médicos. Escribe 'ayuda' para ver ejemplos.")
        return None

    def _r_ayuda(self, ctx: Contexto):
        if ctx.texto in {"ayuda", "help"} or ctx.tiene("que puedes", "que sabes hacer", "que preguntas", "como funcionas"):
            return AYUDA
        return None

    def _r_gracias(self, ctx: Contexto):
        if ctx.tiene("gracias") and not ctx.entidades:
            return "¡De nada! ¿Algo más sobre los pacientes?"
        return None

    # Datos de un paciente (usados por varias reglas)
    def _g(self, p: str, masculino: str, femenino: str) -> str:
        """Elige la palabra según el género del paciente: alérgico / alérgica."""
        return femenino if self.kb.es_cierto(f"genero({p}, femenino)") else masculino

    def _datos(self, p: str) -> dict:
        kb = self.kb
        return {
            "genero": kb.valor("G", f"genero({p}, G)"),
            "edad": kb.valor("E", f"edad({p}, E)"),
            "rango": kb.valor("R", f"rango_edad({p}, R)"),
            "motivo": kb.valor("M", f"internado_por({p}, M)"),
            "categoria": kb.valor("C", f"categoria_paciente({p}, C)"),
            "gravedad": kb.valor("G", f"gravedad({p}, G)"),
            "servicio": kb.valor("S", f"servicio({p}, S)"),
            "prioridad": kb.valor("N", f"prioridad({p}, N)"),
            "medicos": kb.lista("M", f"atendido_por({p}, M)"),
        }

    def _ficha(self, p: str) -> str:
        d = self._datos(p)
        riesgo = "Sí" if self.kb.es_cierto(f"alto_riesgo({p})") else "No"
        lineas = [
            f"{nombre(p, True)}: {d['edad']} años, género {d['genero']}, {nombre(d['rango'])}.",
            f"  • Motivo: {nombre(d['motivo'])} (categoría {nombre(d['categoria'])}).",
            f"  • Gravedad: {nombre(d['gravedad'])} · Servicio: {nombre(d['servicio'])}.",
            f"  • Médicos tratantes: {enumerar(d['medicos'])}.",
            f"  • Prioridad {d['prioridad']} ({DESCRIPCION_PRIORIDAD[d['prioridad']]}) · Alto riesgo: {riesgo}.",
        ]
        return "\n".join(lineas)

    def _razon_riesgo(self, p: str) -> str:
        d = self._datos(p)
        if d["gravedad"] == "critica":
            return "su estado es crítico"
        if d["gravedad"] == "grave" and d["rango"] == "adulto_mayor":
            return "está grave y es adulto mayor (60 años o más)"
        return ""

    # Dos pacientes
    def _r_dos_pacientes(self, ctx: Contexto):
        pacientes = ctx.valores("paciente")
        if len(pacientes) < 2:
            return None
        a, b = pacientes[:2]
        A, B = nombre(a, True), nombre(b, True)
        da, db = self._datos(a), self._datos(b)

        if ctx.tiene("grave", "peor", "critic", "prioridad", "urgente"):
            if self.kb.es_cierto(f"mas_grave_que({a}, {b})"):
                return f"{A} está más grave ({nombre(da['gravedad'])}) que {B} ({nombre(db['gravedad'])})."
            if self.kb.es_cierto(f"mas_grave_que({b}, {a})"):
                return f"{B} está más grave ({nombre(db['gravedad'])}) que {A} ({nombre(da['gravedad'])})."
            return f"{A} y {B} tienen la misma gravedad: {nombre(da['gravedad'])}."
        if ctx.tiene("edad", "mayor", "menor", "viej", "joven"):
            if da["edad"] == db["edad"]:
                return f"{A} y {B} tienen la misma edad ({da['edad']} años)."
            mayor, menor = (a, b) if da["edad"] > db["edad"] else (b, a)
            return (f"{nombre(mayor, True)} es mayor ({self._datos(mayor)['edad']} años) que "
                    f"{nombre(menor, True)} ({self._datos(menor)['edad']} años).")

        comun = []
        cat = self.kb.lista("C", f"misma_categoria({a}, {b}, C)")
        if cat:
            comun.append(f"motivo de la misma categoría ({nombre(cat[0])})")
        serv = self.kb.lista("S", f"mismo_servicio({a}, {b}, S)")
        if serv:
            comun.append(f"están en el mismo servicio ({nombre(serv[0])})")
        meds = self.kb.lista("M", f"comparten_medico({a}, {b}, M)")
        if meds:
            comun.append(f"comparten médico ({enumerar(meds)})")
        if da["gravedad"] == db["gravedad"]:
            comun.append(f"misma gravedad ({nombre(da['gravedad'])})")
        if da["rango"] == db["rango"]:
            comun.append(f"mismo rango de edad ({nombre(da['rango'])})")
        if da["genero"] == db["genero"]:
            comun.append(f"mismo género ({da['genero']})")
        if not comun:
            return f"{A} y {B} no tienen nada relevante en común."
        return f"{A} y {B} tienen en común: " + "; ".join(comun) + "."

    # Médico y paciente
    def _r_medico_paciente(self, ctx: Contexto):
        medico, p = ctx.uno("medico"), ctx.uno("paciente")
        if not (medico and p):
            return None
        M, P = con_articulo(medico), nombre(p, True)
        if ctx.tiene("puede", "podria", "podrian"):
            esp = self.kb.valor("E", f"medico({medico}, E)")
            adecuadas = self.kb.lista("E", f"especialidad_adecuada({p}, E)")
            if self.kb.es_cierto(f"puede_atender({medico}, {p})"):
                return f"Sí, {M} ({nombre(esp)}) puede atender a {P}: su especialidad es adecuada para el caso."
            return (f"No, {M} es de {nombre(esp)} y {P} necesita alguna de estas especialidades: "
                    f"{enumerar(adecuadas)}.")
        if self.kb.es_cierto(f"atendido_por({p}, {medico})"):
            return f"Sí, {M} es parte del equipo tratante de {P}."
        tratantes = self.kb.lista("M", f"atendido_por({p}, M)")
        return f"No. Los médicos tratantes de {P} son: {enumerar(tratantes)}."

    # Preguntas sobre un paciente
    def _r_paciente(self, ctx: Contexto):
        p = ctx.uno("paciente")
        if not p:
            return None
        kb = self.kb
        P = nombre(p, True)
        d = self._datos(p)

        if ctx.tiene("riesgo"):
            if kb.es_cierto(f"alto_riesgo({p})"):
                return f"Sí, {P} es paciente de alto riesgo: {self._razon_riesgo(p)}."
            if d["gravedad"] == "grave":
                return f"No, {P} está en estado grave, pero no es de alto riesgo porque no es adulto mayor."
            return f"No, {P} no es de alto riesgo: su estado es {estado(d['gravedad'])}."
        if ctx.tiene("prioridad", "urgencia"):
            return f"{P} tiene prioridad {d['prioridad']} ({DESCRIPCION_PRIORIDAD[d['prioridad']]})."
        if ctx.tiene("uci", "intensiv") and ctx.tiene("requier", "necesit", "deberia", "debe"):
            if kb.es_cierto(f"requiere_uci({p})"):
                ubicacion = "y ya está en la UCI" if d["servicio"] == "uci" else f"pero está en {nombre(d['servicio'])}"
                return f"Sí, {P} requiere UCI por su estado crítico {ubicacion}."
            return f"No, {P} no requiere UCI: su estado es {estado(d['gravedad'])}."
        if ctx.pide_alta():
            if kb.es_cierto(f"candidato_alta({p})"):
                return f"Sí, {P} es {self._g(p, 'candidato', 'candidata')} a alta: está en estado leve."
            return f"No, {P} aún no es {self._g(p, 'candidato', 'candidata')} a alta: su estado es {estado(d['gravedad'])}."
        if ctx.tiene("puede atender", "pueden atender", "podria atender", "podrian atender"):
            medicos = kb.lista("M", f"puede_atender(M, {p})")
            detalle = "; ".join(f"{nombre(m)} ({nombre(kb.valor('E', f'medico({m}, E)'))})" for m in medicos)
            return f"Pueden atender a {P}: {detalle}."
        if ctx.tiene("misma sala", "mismo servicio", "companer", "junto"):
            otros = kb.lista("X", f"mismo_servicio({p}, X, _)")
            if not otros:
                return f"{P} es {self._g(p, 'el único paciente', 'la única paciente')} en {nombre(d['servicio'])}."
            return f"Con {P} en {nombre(d['servicio'])} están: {enumerar(otros, True)}."
        if ctx.tiene("comun", "compart", "parecid", "similar"):
            return self._relacionados(p)
        if ctx.tiene("medico", "doctor", "atiende", "tratante"):
            return f"Médicos tratantes de {P}: {enumerar(d['medicos'])}."
        servicio_preguntado = ctx.uno("servicio")
        if servicio_preguntado and not ctx.tiene("medico", "doctor"):  # "¿Rosa está en la UCI?"
            si = servicio_preguntado == d["servicio"]
            return (f"{'Sí' if si else 'No'}, {P} {'' if si else 'no '}está en {nombre(servicio_preguntado)}"
                    + ("." if si else f": está en {nombre(d['servicio'])}."))
        if ctx.tiene("donde", "servicio", "sala", "unidad", "piso"):
            return f"{P} está en el servicio de {nombre(d['servicio'])}."
        if ctx.tiene("por que", "motivo", "razon", "internad", "diagnostic", "que tiene", "causa"):
            return (f"{P} está {self._g(p, 'internado', 'internada')} por {nombre(d['motivo'])} "
                    f"(categoría {nombre(d['categoria'])}).")
        if ctx.tiene("grave", "gravedad", "estado", "como esta", "critic", "leve", "moderad"):
            return f"{P} está en estado {estado(d['gravedad'])}."
        if ctx.tiene("edad", "anos", "rango", "genero", "sexo", "mayor", "menor", "nino", "adolescente"):
            return f"{P} tiene {d['edad']} años (rango {nombre(d['rango'])}) y es de género {d['genero']}."
        return self._ficha(p)

    def _relacionados(self, p: str) -> str:
        kb = self.kb
        P = nombre(p, True)
        lineas = [f"Pacientes relacionados con {P}:"]
        cat = kb.pares("X", "C", f"misma_categoria({p}, X, C)")
        if cat:
            lineas.append(f"  • Misma categoría de motivo ({nombre(cat[0][1])}): {enumerar([x for x, _ in cat], True)}.")
        serv = kb.pares("X", "S", f"mismo_servicio({p}, X, S)")
        if serv:
            lineas.append(f"  • Mismo servicio ({nombre(serv[0][1])}): {enumerar([x for x, _ in serv], True)}.")
        meds = kb.pares("X", "M", f"comparten_medico({p}, X, M)")
        if meds:
            grupos: dict = {}
            for x, m in meds:
                grupos.setdefault(m, []).append(x)
            for m, xs in grupos.items():
                lineas.append(f"  • También {'atendidos' if len(xs) > 1 else 'atendido'} por {con_articulo(m)}: {enumerar(xs, True)}.")
        if len(lineas) == 1:
            return f"{P} no comparte categoría, servicio ni médico con otros pacientes."
        return "\n".join(lineas)
    
    # Preguntas sobre un médico
    def _r_medico(self, ctx: Contexto):
        medico = ctx.uno("medico")
        if not medico:
            return None
        kb = self.kb
        M = capitalizar(con_articulo(medico))
        esp = kb.valor("E", f"medico({medico}, E)")
        pacientes = kb.lista("P", f"atendido_por(P, {medico})")

        if ctx.tiene("especialidad", "area", "que es", "que hace"):
            return f"{M} es especialista en {nombre(esp)}."
        if ctx.tiene("puede", "podria"):
            posibles = kb.lista("P", f"puede_atender({medico}, P)")
            if not posibles:
                return f"Según su especialidad, {M} no es adecuado para ningún paciente actual."
            return f"Por su especialidad ({nombre(esp)}), {M} puede atender a: {enumerar(posibles, True)}."
        if ctx.tiene("cuantos", "cuantas", "carga"):
            n = kb.valor("N", f"carga_medico({medico}, N)")
            return f"{M} atiende a {pacientes_txt(n)}."
        detalle = ", ".join(f"{nombre(x, True)} ({nombre(kb.valor('G', f'gravedad({x}, G)'))})" for x in pacientes)
        return f"{M} ({nombre(esp)}) atiende a {pacientes_txt(len(pacientes))}: {detalle}."


    def _r_motivo(self, ctx: Contexto):
        motivo = ctx.uno("motivo")
        if not motivo or ctx.tiene("paciente", "quien", "quienes", "cuantos", "cuantas", "hay"):
            return None
        if not (ctx.tiene("que es", "en que consiste", "significa", "definicion", "explica", "categoria")
                or len(ctx.entidades) == len(ctx.texto.split()) or len(ctx.texto.split()) <= 3):
            return None
        kb = self.kb
        descripcion = kb.valor("D", f"descripcion_motivo({motivo}, D)") or ""
        categoria = kb.valor("C", f"motivo({motivo}, C)")
        especialidad = kb.valor("E", f"especialidad_de({categoria}, E)")
        internados = kb.lista("P", f"internado_por(P, {motivo})")
        partes = [f"{capitalizar(nombre(motivo))}: {descripcion}".strip(),
                  f"Categoría: {nombre(categoria)}. Especialidad que lo trata: {nombre(especialidad)}."]
        if internados:
            partes.append(f"Internados por este motivo: {enumerar(internados, True)}.")
        else:
            partes.append("Actualmente no hay pacientes internados por este motivo.")
        return "\n".join(partes)

    # Filtros 
    def _filtros(self, ctx: Contexto) -> tuple[list[str], list[str]]:
        objetivos = ["genero(P, _)"]  # base: todos los pacientes
        descripciones: list[str] = []

        # Plantillas: (objetivo Prolog, descripción afirmativa, descripción negada)
        plantillas = {
            "genero": ("genero(P, {v})", "de género {n}", "que no son de género {n}"),
            "rango": ("rango_edad(P, {v})", "en el rango {n}", "fuera del rango {n}"),
            "gravedad": ("gravedad(P, {v})", "en estado {e}", "que no están en estado {e}"),
            "servicio": ("servicio(P, {v})", "en {n}", "fuera de {n}"),
            "especialidad": ("(atendido_por(P, M{i}), medico(M{i}, {v}))", "atendidos por {n}", "no atendidos por {n}"),
            "especialista": ("(atendido_por(P, M{i}), medico(M{i}, {v}))", "atendidos por {n}", "no atendidos por {n}"),
            "motivo": ("internado_por(P, {v})", "internados por {n}", "no internados por {n}"),
            "categoria": ("categoria_paciente(P, {v})", "con motivo de tipo {n}", "con motivo que no es de tipo {n}"),
            "medico": ("atendido_por(P, {v})", "atendidos por {n}", "no atendidos por {n}"),
        }

        # Entidades de la misma clase se combinan con "o": "graves o críticos".
        grupos: dict[str, list[Entidad]] = {}
        for e in ctx.entidades:
            if e.clase in plantillas:
                grupos.setdefault(e.clase, []).append(e)
        for i, (clase, entidades) in enumerate(grupos.items()):
            objetivo, desc_si, desc_no = plantillas[clase]
            positivas = [e for e in entidades if not e.negada]
            negadas = [e for e in entidades if e.negada]
            if positivas:
                opciones = [objetivo.format(v=e.valor, i=i) for e in positivas]
                objetivos.append("(" + " ; ".join(opciones) + ")")
                valores = [e.valor for e in positivas]
                descripciones.append(desc_si.format(
                    n=enumerar(valores, conjuncion="o"),
                    e=" o ".join(estado(v) for v in valores)))
            for e in negadas:
                objetivos.append("\\+ " + objetivo.format(v=e.valor, i=i))
                descripciones.append(desc_no.format(n=nombre(e.valor), e=estado(e.valor)))

        # Filtros por palabras clave
        if ctx.tiene("alto riesgo", "riesgo alto"):
            objetivos.append("alto_riesgo(P)")
            descripciones.append("de alto riesgo")
        if ctx.tiene("requier", "necesit") and ctx.tiene("uci", "intensiv"):
            objetivos.append("requiere_uci(P)")
            descripciones.append("que requieren UCI")
        if ctx.pide_alta():
            objetivos.append("candidato_alta(P)")
            descripciones.append("candidatos a alta")
        if ctx.tiene("menor de edad", "menores de edad"):
            objetivos.append("menor_de_edad(P)")
            descripciones.append("menores de edad")

        # Filtros numéricos
        if m := re.search(r"prioridad (\d)", ctx.texto):
            objetivos.append(f"prioridad(P, {m.group(1)})")
            descripciones.append(f"con prioridad {m.group(1)}")
        if m := re.search(r"entre (\d+) y (\d+) anos", ctx.texto):
            objetivos.append(f"(edad(P, E), E >= {m.group(1)}, E =< {m.group(2)})")
            descripciones.append(f"de entre {m.group(1)} y {m.group(2)} años")
        if m := re.search(r"mayores de (\d+)", ctx.texto):
            objetivos.append(f"(edad(P, E), E > {m.group(1)})")
            descripciones.append(f"mayores de {m.group(1)} años")
        if m := re.search(r"menores de (\d+)", ctx.texto):
            objetivos.append(f"(edad(P, E), E < {m.group(1)})")
            descripciones.append(f"menores de {m.group(1)} años")

        return objetivos, descripciones

    def _filtrados(self, ctx: Contexto) -> tuple[list[str], str, bool]:
        """Pacientes que cumplen los filtros, su descripción y si había algún filtro."""
        objetivos, descripciones = self._filtros(ctx)
        pacientes = self.kb.lista("P", ", ".join(objetivos))
        return pacientes, " ".join(descripciones), len(objetivos) > 1

    # Estadísticas
    def _r_estadisticas(self, ctx: Contexto):
        kb = self.kb
        pacientes, desc, _ = self._filtrados(ctx)
        sufijo = f" ({desc})" if desc else ""

        if ctx.tiene("promedio", "media"):
            if not pacientes:
                return f"No hay pacientes{sufijo} para calcular un promedio."
            edades = [kb.valor("E", f"edad({p}, E)") for p in pacientes]
            return f"Edad promedio{sufijo}: {sum(edades) / len(edades):.1f} años ({pacientes_txt(len(edades))})."

        def tabla(titulo: str, valores: list[str], objetivo: str) -> str:
            filas = []
            for v in valores:
                n = len([p for p in pacientes if kb.es_cierto(objetivo.format(p=p, v=v))])
                if n:
                    filas.append(f"    {capitalizar(nombre(v))}: {n}")
            return f"  • {titulo}:\n" + "\n".join(filas)

        secciones = {
            "gravedad": ("Por gravedad", ORDEN_GRAVEDAD, "gravedad({p}, {v})"),
            "servicio": ("Por servicio", kb.lista("S", "servicio(_, S)"), "servicio({p}, {v})"),
            "genero": ("Por género", kb.lista("G", "genero(_, G)"), "genero({p}, {v})"),
            "rango": ("Por rango de edad", ORDEN_RANGO, "rango_edad({p}, {v})"),
            "categoria": ("Por categoría de motivo", kb.lista("C", "motivo(_, C)"), "categoria_paciente({p}, {v})"),
        }
        claves = {
            "gravedad": ("por gravedad", "segun gravedad", "por estado"),
            "servicio": ("por servicio", "por unidad", "por area", "segun servicio"),
            "genero": ("por genero", "por sexo", "segun genero"),
            "rango": ("por edad", "por rango", "segun edad", "por grupo etario"),
            "categoria": ("por categoria", "por motivo", "por tipo", "segun motivo"),
        }
        pedidas = [k for k, cl in claves.items() if ctx.tiene(*cl)]
        if not pedidas and ctx.tiene("resumen", "estadistic", "panorama", "distribucion"):
            pedidas = list(secciones)
        if ctx.tiene("por medico", "carga de trabajo", "por doctor"):
            filas = [f"    {nombre(m)}: {kb.valor('N', f'carga_medico({m}, N)')}"
                     for m in kb.lista("M", "medico(M, _)")]
            return "Pacientes por médico:\n" + "\n".join(filas)
        if not pedidas:
            return None
        lineas = [f"{capitalizar(pacientes_txt(len(pacientes)))} internados{sufijo}:"]
        for k in pedidas:
            titulo, valores, objetivo = secciones[k]
            lineas.append(tabla(titulo, valores, objetivo))
        return "\n".join(lineas)

    # Extremos
    def _r_extremos(self, ctx: Contexto):
        kb = self.kb
        criterios = [
            (("mas grave", "mas critic", "peor estado"), "gravedad", True),
            (("mayor edad", "mas viej", "mas ancian", "de mas edad", "mas edad"), "edad", True),
            (("menor edad", "mas joven", "mas chic", "mas pequen", "de menos edad"), "edad", False),
        ]
        for claves, atributo, maximo in criterios:
            if not ctx.tiene(*claves):
                continue
            if atributo == "gravedad":  # "más grave" no es un filtro por gravedad
                ctx = Contexto(ctx.texto, [e for e in ctx.entidades if e.clase != "gravedad"])
            pacientes, desc, _ = self._filtrados(ctx)
            if not pacientes:
                return f"No hay pacientes {desc}."
            if atributo == "gravedad":
                valor = {p: 4 - ORDEN_GRAVEDAD.index(self._datos(p)["gravedad"]) for p in pacientes}
            else:
                valor = {p: kb.valor("E", f"edad({p}, E)") for p in pacientes}
            objetivo = max(valor.values()) if maximo else min(valor.values())
            elegidos = [p for p in pacientes if valor[p] == objetivo]
            if atributo == "gravedad":
                detalle = f"estado {estado(ORDEN_GRAVEDAD[4 - objetivo])}"
            else:
                detalle = f"{objetivo} años"
            entre = f" (entre los pacientes {desc})" if desc else ""
            return f"{enumerar(elegidos, True)}{entre}: {detalle}."
        return None

    # Listado de médicos
    def _r_medicos(self, ctx: Contexto):
        kb = self.kb
        if ctx.tiene("medico", "doctor") and ctx.tiene("mas pacientes", "mas carga", "mas ocupad"):
            cargas = {m: kb.valor("N", f"carga_medico({m}, N)") for m in kb.lista("M", "medico(M, _)")}
            maximo = max(cargas.values())
            elegidos = [m for m, n in cargas.items() if n == maximo]
            return f"Con más pacientes: {enumerar(elegidos)} ({pacientes_txt(maximo)})."
        if ctx.todas("paciente") or ctx.tiene("paciente", "internad"):
            return None
        especialidades = ctx.valores("especialista") + [
            v for v in ctx.valores("especialidad") + ctx.valores("servicio") if ctx.tiene("medico", "doctor", "especialista")
        ]
        if not (ctx.todas("especialista") or ctx.tiene("medico", "doctor", "especialista")):
            return None
        if especialidades:
            medicos = kb.lista("M", "(" + " ; ".join(f"medico(M, {e})" for e in especialidades) + ")")
            if not medicos:
                return f"No hay médicos de {enumerar(especialidades, conjuncion='o')} en la base."
            return f"Médicos de {enumerar(especialidades, conjuncion='o')}: {enumerar(medicos)}."
        filas = [f"  • {nombre(m)}: {nombre(e)}" for m, e in kb.pares("M", "E", "medico(M, E)")]
        return "Médicos del hospital:\n" + "\n".join(filas)

    # Listado de pacientes con filtros combinados
    def _r_listado(self, ctx: Contexto):
        pacientes, desc, hay_filtro = self._filtrados(ctx)
        if not hay_filtro and not ctx.tiene("paciente", "internad", "quienes", "quien", "hay"):
            return None
        frase = f"pacientes {desc}".strip()
        if ctx.tiene("cuantos", "cuantas", "numero de", "cantidad"):
            if not pacientes:
                return f"No hay {frase}."
            if len(pacientes) == 1:
                desc = singular(desc)
            return f"Hay {pacientes_txt(len(pacientes))}{(' ' + desc) if desc else ''}."
        if not pacientes:
            return f"No encontré {frase}."
        if len(pacientes) == 1:
            desc = singular(desc)
        return f"Encontré {pacientes_txt(len(pacientes))}{(' ' + desc) if desc else ''}: {enumerar(pacientes, True)}."


AYUDA = """Puedo responder preguntas sobre los pacientes hospitalizados. Algunos ejemplos:
  • Háblame de Raúl / ¿Por qué está internado Héctor? / ¿Qué gravedad tiene Rosa?
  • ¿Es Gloria de alto riesgo? / ¿Qué prioridad tiene Matías? / ¿Puede Isidora irse de alta?
  • ¿Qué médico atiende a Raúl? / ¿Está Rosa en la UCI?
  • ¿Quién atiende a Rodrigo? / ¿Quién puede atender a Sergio? / ¿A quién atiende el Dr. Pérez?
  • ¿Qué tienen en común Joaquín y Tomás? / ¿Quién está más grave, Rosa o Gloria?
  • Mujeres en estado grave / Adultos mayores en medicina interna / Pacientes en la UCI
  • ¿Cuántos pacientes tienen problemas cardiovasculares? / Hombres que no están graves
  • Pacientes mayores de 60 / ¿Quién es el paciente más joven?
  • Pacientes por gravedad / Resumen / Edad promedio de los pacientes graves
  • ¿Qué es la pielonefritis? / ¿Qué médicos hay? / ¿Quién es el cardiólogo?
Escribe 'salir' para terminar."""


# INTERFAZ DE CONSOLA
COMANDOS_SALIDA = {"salir", "exit", "quit", "chao", "adios", "adiós"}

def main() -> None:
    try:
        bot = Chatbot()
    except FileNotFoundError as error:
        print(error)
        sys.exit(1)

    if len(sys.argv) > 1:
        print(bot.responder(" ".join(sys.argv[1:])))
        return

    print("Chatbot de pacientes hospitalizados 🏥  (escribe 'ayuda' para ver ejemplos, "
          "'recargar' tras editar el .pl, 'salir' para terminar)\n")
    while True:
        try:
            pregunta = input("Tú: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n¡Hasta luego!")
            break
        if pregunta.lower() in COMANDOS_SALIDA:
            print("Bot: ¡Hasta luego!")
            break
        if pregunta.lower() == "recargar":
            bot.recargar()
            print("Bot: Base de conocimiento recargada.\n")
            continue
        print(f"Bot: {bot.responder(pregunta)}\n")


if __name__ == "__main__":
    main()
